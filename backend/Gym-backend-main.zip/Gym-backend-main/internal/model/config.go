package model

type Config struct {
	Key   string `json:"key"`
	Value string `json:"value"`
	Type  string `json:"type"`
}
