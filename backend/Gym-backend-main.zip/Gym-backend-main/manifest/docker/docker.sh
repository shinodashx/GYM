#!/bin/bash

# This shell is executed before docker build.





