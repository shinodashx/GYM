# License

You can find more details about the license at https://material-ui.com/store/license/