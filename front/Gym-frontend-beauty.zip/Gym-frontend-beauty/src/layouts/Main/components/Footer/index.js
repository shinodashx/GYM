export { default } from './Footer';
