export { default } from './Bot';
