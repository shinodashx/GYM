export { default } from './Cours';
