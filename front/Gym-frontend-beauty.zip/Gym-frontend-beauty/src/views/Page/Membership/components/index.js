export { default as Hero } from './Hero';
export { default as Advantages } from './Advantages';
export { default as Reviews } from './Reviews';
export { default as PricingCards } from './PricingCards';
