export { default } from './Payfor';
