export { default } from './PayforRegular';
