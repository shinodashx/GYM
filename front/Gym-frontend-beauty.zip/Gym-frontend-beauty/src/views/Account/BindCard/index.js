export { default } from './BindCard';
