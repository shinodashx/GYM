export { default as Page } from './Page';
