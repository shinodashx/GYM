export { default as TabComponent } from './TabComponent';
