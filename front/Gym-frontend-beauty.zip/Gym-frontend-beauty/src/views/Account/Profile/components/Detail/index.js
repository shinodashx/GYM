export { default } from './Detail';
