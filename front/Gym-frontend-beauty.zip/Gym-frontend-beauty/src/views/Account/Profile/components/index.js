export { default as Portrait } from './Portrait';
export { default as Detail } from './Detail';
