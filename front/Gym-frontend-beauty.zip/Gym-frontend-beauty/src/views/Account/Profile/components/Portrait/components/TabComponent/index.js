export { default } from './TabComponent';
