export { default as Contact } from './Contact';
export { default as Faq } from './Faq';
export { default as Privacy } from './Privacy';
export { default as About } from './About';
