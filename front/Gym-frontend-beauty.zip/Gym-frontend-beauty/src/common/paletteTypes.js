const palettes = ['blue'];

export default palettes;
