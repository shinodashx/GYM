import request from "@/utils/request";

// export function ask(data) {
//     return request({
//         url:'http://38.47.115.99:3700/v1/chat/completions',
//         method:'post',
//         data
//     });
// }