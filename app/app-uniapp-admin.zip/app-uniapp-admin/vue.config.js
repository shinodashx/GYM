module.exports = {
    transpileDependencies: ['uview-ui','@dcloudio/uni-ui'],
}